"""Plotting routines using Matplotlib for speech signals, F0 contours, and ACF/AMDF."""
import os
from typing import Optional
import matplotlib.pyplot as plt
import numpy as np
from src.analysis.evaluation import format_metric


def plot_frame_acf_comparison(
    voiced_frame: np.ndarray,
    voiced_acf: np.ndarray,
    voiced_f0: float,
    voiced_lag: int,
    voiced_peak: float,
    unvoiced_frame: np.ndarray,
    unvoiced_acf: np.ndarray,
    unvoiced_lag: int,
    unvoiced_peak: float,
    sample_rate: int,
    f0_min: float = 70.0,
    f0_max: float = 400.0,
    save_path: Optional[str] = None,
    title: str = "So sánh Hàm Tự Tương Quan (ACF): Khung Hữu Thanh vs Vô Thanh",
):
    """Plot a comprehensive 2x2 comparison between a Voiced frame and an Unvoiced frame.

    - Top Left: Voiced Frame Waveform (shows quasi-periodicity).
    - Bottom Left: Voiced Frame Normalized ACF (shows prominent peak at pitch period T0).
    - Top Right: Unvoiced Frame Waveform (noise-like, non-periodic).
    - Bottom Right: Unvoiced Frame Normalized ACF (rapid decay, no dominant peak).
    """
    n_v = len(voiced_frame)
    n_uv = len(unvoiced_frame)

    t_v = np.arange(n_v) / sample_rate * 1000.0  # ms
    t_uv = np.arange(n_uv) / sample_rate * 1000.0  # ms

    lag_v_ms = np.arange(len(voiced_acf)) / sample_rate * 1000.0  # ms
    lag_uv_ms = np.arange(len(unvoiced_acf)) / sample_rate * 1000.0  # ms

    lag_min = int(round(sample_rate / f0_max))
    lag_max = int(round(sample_rate / f0_min))
    lag_min_ms = lag_min / sample_rate * 1000.0
    lag_max_ms = lag_max / sample_rate * 1000.0

    plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    fig.suptitle(title, fontsize=15, fontweight="bold", y=0.98)

    # Subplot 1: Voiced Waveform
    ax1 = axes[0, 0]
    ax1.plot(t_v, voiced_frame, color="#1f77b4", linewidth=1.5, label="Voiced signal")
    ax1.set_title("1. Tín hiệu Khung Hữu Thanh (Voiced Frame)", fontsize=12, fontweight="bold", color="#1f77b4")
    ax1.set_xlabel("Thời gian (ms)")
    ax1.set_ylabel("Biên độ chuẩn hóa")
    ax1.grid(True, linestyle="--", alpha=0.6)
    ax1.legend(loc="upper right")

    # Subplot 2: Voiced ACF
    ax2 = axes[1, 0]
    ax2.plot(lag_v_ms, voiced_acf, color="#1f77b4", linewidth=1.5, label="Normalized ACF R(τ)")
    # Highlight pitch search region [lag_min, lag_max]
    ax2.axvspan(lag_min_ms, lag_max_ms, color="green", alpha=0.15, label=f"Vùng tìm F0 [{f0_min:.0f}-{f0_max:.0f} Hz]")
    # Highlight pitch peak
    t0_ms = voiced_lag / sample_rate * 1000.0
    ax2.plot(t0_ms, voiced_peak, "ro", markersize=8, label=f"Đỉnh T0 = {t0_ms:.2f} ms\nF0 = {voiced_f0:.1f} Hz (Peak: {voiced_peak:.3f})")
    ax2.axvline(t0_ms, color="red", linestyle="--", alpha=0.7)
    ax2.set_title(f"ACF Khung Hữu Thanh -> F0 = {voiced_f0:.1f} Hz (Xác định)", fontsize=12, fontweight="bold", color="darkgreen")
    ax2.set_xlabel("Độ trễ lag τ (ms)")
    ax2.set_ylabel("ACF chuẩn hóa R(τ)/R(0)")
    ax2.set_ylim(-0.6, 1.05)
    ax2.grid(True, linestyle="--", alpha=0.6)
    ax2.legend(loc="upper right")

    # Subplot 3: Unvoiced Waveform
    ax3 = axes[0, 1]
    ax3.plot(t_uv, unvoiced_frame, color="#d62728", linewidth=1.2, label="Unvoiced signal")
    ax3.set_title("2. Tín hiệu Khung Vô Thanh (Unvoiced Frame)", fontsize=12, fontweight="bold", color="#d62728")
    ax3.set_xlabel("Thời gian (ms)")
    ax3.set_ylabel("Biên độ chuẩn hóa")
    ax3.grid(True, linestyle="--", alpha=0.6)
    ax3.legend(loc="upper right")

    # Subplot 4: Unvoiced ACF
    ax4 = axes[1, 1]
    ax4.plot(lag_uv_ms, unvoiced_acf, color="#d62728", linewidth=1.5, label="Normalized ACF R(τ)")
    ax4.axvspan(lag_min_ms, lag_max_ms, color="orange", alpha=0.15, label=f"Vùng tìm F0 [{f0_min:.0f}-{f0_max:.0f} Hz]")
    unvoiced_t0_ms = unvoiced_lag / sample_rate * 1000.0
    ax4.plot(unvoiced_t0_ms, unvoiced_peak, "kx", markersize=8, markeredgewidth=2, label=f"Cực đại cục bộ ({unvoiced_peak:.3f} < Ngưỡng)")
    ax4.set_title("ACF Khung Vô Thanh -> F0 không xác định (Undefined)", fontsize=12, fontweight="bold", color="darkred")
    ax4.set_xlabel("Độ trễ lag τ (ms)")
    ax4.set_ylabel("ACF chuẩn hóa R(τ)/R(0)")
    ax4.set_ylim(-0.6, 1.05)
    ax4.grid(True, linestyle="--", alpha=0.6)
    ax4.legend(loc="upper right")

    plt.tight_layout(rect=[0, 0, 1, 0.95])

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")

    plt.close(fig)
    return fig


def plot_frame_amdf_comparison(
    voiced_frame: np.ndarray,
    voiced_amdf: np.ndarray,
    voiced_f0: float,
    voiced_lag: int,
    voiced_dip: float,
    unvoiced_frame: np.ndarray,
    unvoiced_amdf: np.ndarray,
    unvoiced_lag: int,
    unvoiced_dip: float,
    sample_rate: int,
    f0_min: float = 70.0,
    f0_max: float = 400.0,
    threshold: Optional[float] = None,
    save_path: Optional[str] = None,
    title: str = "So sánh Hàm Hiệu Độ Lớn Trung Bình (AMDF): Khung Hữu Thanh vs Vô Thanh",
):
    """Plot a comprehensive 2x2 comparison between a Voiced frame and an Unvoiced frame for AMDF:

    - Top Left: Voiced Frame Waveform (shows quasi-periodicity).
    - Bottom Left: Voiced Frame Normalized AMDF (shows deep local dip at pitch period T0).
    - Top Right: Unvoiced Frame Waveform (noise-like, non-periodic).
    - Bottom Right: Unvoiced Frame Normalized AMDF (stays high, no deep dip).
    """
    n_v = len(voiced_frame)
    n_uv = len(unvoiced_frame)

    t_v = np.arange(n_v) / sample_rate * 1000.0  # ms
    t_uv = np.arange(n_uv) / sample_rate * 1000.0  # ms

    lag_v_ms = np.arange(len(voiced_amdf)) / sample_rate * 1000.0  # ms
    lag_uv_ms = np.arange(len(unvoiced_amdf)) / sample_rate * 1000.0  # ms

    lag_min = int(round(sample_rate / f0_max))
    lag_max = int(round(sample_rate / f0_min))
    lag_min_ms = lag_min / sample_rate * 1000.0
    lag_max_ms = lag_max / sample_rate * 1000.0

    plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    fig.suptitle(title, fontsize=15, fontweight="bold", y=0.98)

    # Subplot 1: Voiced Waveform
    ax1 = axes[0, 0]
    ax1.plot(t_v, voiced_frame, color="#1f77b4", linewidth=1.5, label="Voiced signal")
    ax1.set_title("1. Tín hiệu Khung Hữu Thanh (Voiced Frame)", fontsize=12, fontweight="bold", color="#1f77b4")
    ax1.set_xlabel("Thời gian (ms)")
    ax1.set_ylabel("Biên độ chuẩn hóa")
    ax1.grid(True, linestyle="--", alpha=0.6)
    ax1.legend(loc="upper right")

    # Subplot 2: Voiced AMDF
    ax2 = axes[1, 0]
    ax2.plot(lag_v_ms, voiced_amdf, color="#1f77b4", linewidth=1.5, label="Normalized AMDF D(τ)")
    ax2.axvspan(lag_min_ms, lag_max_ms, color="green", alpha=0.15, label=f"Vùng tìm F0 [{f0_min:.0f}-{f0_max:.0f} Hz]")
    t0_ms = voiced_lag / sample_rate * 1000.0
    ax2.plot(t0_ms, voiced_dip, "ro", markersize=8, label=f"Đáy T0 = {t0_ms:.2f} ms\nF0 = {voiced_f0:.1f} Hz (Dip: {voiced_dip:.3f})")
    ax2.axvline(t0_ms, color="red", linestyle="--", alpha=0.7)
    if threshold is not None:
        ax2.axhline(threshold, color="purple", linestyle=":", linewidth=1.8, label=f"Ngưỡng T = {threshold:.3f}")
    ax2.set_title(f"AMDF Khung Hữu Thanh -> F0 = {voiced_f0:.1f} Hz (Đáy cực tiểu sâu)", fontsize=12, fontweight="bold", color="darkgreen")
    ax2.set_xlabel("Độ trễ lag τ (ms)")
    ax2.set_ylabel("AMDF chuẩn hóa D(τ)")
    ax2.set_ylim(-0.05, 1.05)
    ax2.grid(True, linestyle="--", alpha=0.6)
    ax2.legend(loc="upper right")

    # Subplot 3: Unvoiced Waveform
    ax3 = axes[0, 1]
    ax3.plot(t_uv, unvoiced_frame, color="#d62728", linewidth=1.2, label="Unvoiced signal")
    ax3.set_title("2. Tín hiệu Khung Vô Thanh (Unvoiced Frame)", fontsize=12, fontweight="bold", color="#d62728")
    ax3.set_xlabel("Thời gian (ms)")
    ax3.set_ylabel("Biên độ chuẩn hóa")
    ax3.grid(True, linestyle="--", alpha=0.6)
    ax3.legend(loc="upper right")

    # Subplot 4: Unvoiced AMDF
    ax4 = axes[1, 1]
    ax4.plot(lag_uv_ms, unvoiced_amdf, color="#d62728", linewidth=1.5, label="Normalized AMDF D(τ)")
    ax4.axvspan(lag_min_ms, lag_max_ms, color="orange", alpha=0.15, label=f"Vùng tìm F0 [{f0_min:.0f}-{f0_max:.0f} Hz]")
    unvoiced_t0_ms = unvoiced_lag / sample_rate * 1000.0
    ax4.plot(unvoiced_t0_ms, unvoiced_dip, "kx", markersize=8, markeredgewidth=2, label=f"Cực tiểu cục bộ ({unvoiced_dip:.3f} > Ngưỡng)")
    if threshold is not None:
        ax4.axhline(threshold, color="purple", linestyle=":", linewidth=1.8, label=f"Ngưỡng T = {threshold:.3f}")
    ax4.set_title("AMDF Khung Vô Thanh -> F0 không xác định (Không có đáy sâu)", fontsize=12, fontweight="bold", color="darkred")
    ax4.set_xlabel("Độ trễ lag τ (ms)")
    ax4.set_ylabel("AMDF chuẩn hóa D(τ)")
    ax4.set_ylim(-0.05, 1.05)
    ax4.grid(True, linestyle="--", alpha=0.6)
    ax4.legend(loc="upper right")

    plt.tight_layout(rect=[0, 0, 1, 0.95])

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")

    plt.close(fig)
    return fig


def plot_signal_and_f0_contour(
    time_sig: np.ndarray,
    signal: np.ndarray,
    time_f0: np.ndarray,
    f0_contour: np.ndarray,
    ground_truth_segments: Optional[list] = None,
    f0_mean: Optional[float] = None,
    f0_std: Optional[float] = None,
    ref_f0_mean: Optional[float] = None,
    ref_f0_std: Optional[float] = None,
    title: str = "Tín hiệu âm thanh và đường bao tần số F0 (F0 Contour)",
    save_path: Optional[str] = None,
):
    """Plot waveform on top and aligned F0 contour on bottom with segmentation shading."""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
    fig.suptitle(title, fontsize=14, fontweight="bold")

    # Plot waveform
    ax1.plot(time_sig, signal, color="#333333", linewidth=0.8, label="Dạng sóng tín hiệu")
    ax1.set_ylabel("Biên độ")
    ax1.set_title("Dạng sóng tín hiệu (Waveform)", fontsize=11, fontweight="bold")
    ax1.grid(True, linestyle="--", alpha=0.5)

    # Shading ground truth segments if provided
    if ground_truth_segments:
        color_map = {"v": ("#2ca02c", 0.15, "Hữu thanh (V)"), "uv": ("#ff7f0e", 0.15, "Vô thanh (UV)"), "sil": ("#7f7f7f", 0.1, "Khoảng lặng (Sil)")}
        used_labels = set()
        for start, end, lbl in ground_truth_segments:
            if lbl in color_map:
                c, alpha, name = color_map[lbl]
                lbl_name = name if lbl not in used_labels else ""
                ax1.axvspan(start, end, color=c, alpha=alpha, label=lbl_name)
                ax2.axvspan(start, end, color=c, alpha=alpha)
                used_labels.add(lbl)

    ax1.legend(loc="upper right")

    # Plot F0 contour (mask 0 values for voiced contour representation)
    f0_voiced = np.where(f0_contour > 0, f0_contour, np.nan)
    ax2.plot(time_f0, f0_voiced, "b.-", markersize=5, linewidth=1.5, label="F0 ước lượng (Hz)")

    if ref_f0_mean is not None and ref_f0_mean > 0:
        ax2.axhline(ref_f0_mean, color="red", linestyle="--", linewidth=1.5, label=f"Ground Truth F0mean = {ref_f0_mean:.1f} Hz")

    stats_str = ""
    if f0_mean is not None:
        stats_str += f"F0mean ước lượng = {f0_mean:.1f} Hz, F0std = {f0_std:.1f} Hz"
    if ref_f0_mean is not None:
        stats_str += f"\nTham chiếu Lab   = {ref_f0_mean:.1f} Hz, F0std = {format_metric(ref_f0_std, '.1f')} Hz"

    if stats_str:
        ax2.text(0.02, 0.88, stats_str, transform=ax2.transAxes,
                 fontsize=10, bbox=dict(boxstyle="round,pad=0.5", facecolor="white", alpha=0.85, edgecolor="gray"))

    ax2.set_xlabel("Thời gian (giây)", fontsize=11)
    ax2.set_ylabel("Tần số F0 (Hz)", fontsize=11)
    ax2.set_ylim(50, 450)
    ax2.set_title("Đường bao tần số F0 (F0 Contour)", fontsize=11, fontweight="bold")
    ax2.grid(True, linestyle="--", alpha=0.5)
    ax2.legend(loc="upper right")

    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")

    plt.close(fig)
    return fig


def plot_distributions_and_threshold(
    values_v: np.ndarray,
    values_u: np.ndarray,
    mean_v: float,
    std_v: float,
    mean_u: float,
    std_u: float,
    threshold: float,
    method: str = "ACF",
    save_path: Optional[str] = None,
    title: str = "Phân bố biên độ cực trị Voiced/Unvoiced và Ngưỡng phân tách tối ưu T",
):
    """Plot only identifiable Gaussian fits with enough labeled observations."""
    if len(values_v) < 2 or len(values_u) < 2:
        raise ValueError("Gaussian plots require at least 2 labeled V and UV frames")
    if not np.all(np.isfinite([mean_v, std_v, mean_u, std_u, threshold])) or min(std_v, std_u) <= 0:
        raise ValueError("Gaussian plots require finite parameters and positive standard deviations")
    fig, ax = plt.subplots(figsize=(11, 6))

    # Range of values
    all_vals = np.concatenate([values_v, values_u])
    x_min = max(-0.2, float(np.min(all_vals)) - 0.1)
    x_max = min(1.2, float(np.max(all_vals)) + 0.1)
    x_grid = np.linspace(x_min, x_max, 500)

    # Gaussian PDF formula: 1 / (std * sqrt(2*pi)) * exp(-0.5 * ((x - mean)/std)^2)
    pdf_v = (1.0 / (std_v * np.sqrt(2.0 * np.pi))) * np.exp(-0.5 * ((x_grid - mean_v) / std_v) ** 2)
    pdf_u = (1.0 / (std_u * np.sqrt(2.0 * np.pi))) * np.exp(-0.5 * ((x_grid - mean_u) / std_u) ** 2)

    # Histograms (density=True to match PDF scale)
    bins = np.linspace(x_min, x_max, 35)
    ax.hist(values_u, bins=bins, density=True, alpha=0.45, color="#ff7f0e", edgecolor="white", label=f"Vô thanh UV (N={len(values_u)})")
    ax.hist(values_v, bins=bins, density=True, alpha=0.45, color="#2ca02c", edgecolor="white", label=f"Hữu thanh V (N={len(values_v)})")

    # Fitted Gaussian lines
    ax.plot(x_grid, pdf_u, color="#d95f02", linewidth=2.5, linestyle="-", label=f"Gaussian UV: μ={mean_u:.3f}, σ={std_u:.3f}")
    ax.plot(x_grid, pdf_v, color="#1b9e77", linewidth=2.5, linestyle="-", label=f"Gaussian V: μ={mean_v:.3f}, σ={std_v:.3f}")

    # Threshold line
    ax.axvline(threshold, color="red", linestyle="--", linewidth=2.2, label=f"Ngưỡng tối ưu T = {threshold:.3f}")

    if method.lower() == "amdf":
        ax.set_xlabel(f"Biên độ đáy cực tiểu chuẩn hóa của AMDF [D(τ*)]", fontsize=11)
    else:
        ax.set_xlabel(f"Biên độ đỉnh cực đại chuẩn hóa của {method.upper()} [R(τ*)/R(0)]", fontsize=11)
    ax.set_ylabel("Mật độ xác suất (Probability Density)", fontsize=11)
    ax.set_xlim(x_min, x_max)
    ax.grid(True, linestyle="--", alpha=0.6)
    ax.legend(loc="upper right", frameon=True, fontsize=10)

    # Annotation box for summary
    summary_text = (
        f"Thuật toán: {method.upper()}\n"
        f"Khung Hữu thanh: μ_V = {mean_v:.3f}, σ_V = {std_v:.3f}\n"
        f"Khung Vô thanh : μ_U = {mean_u:.3f}, σ_U = {std_u:.3f}\n"
        f"Ngưỡng phân tách T = {threshold:.3f}"
    )
    ax.text(0.03, 0.92, summary_text, transform=ax.transAxes, fontsize=10,
            verticalalignment="top", bbox=dict(boxstyle="round,pad=0.5", facecolor="white", alpha=0.85, edgecolor="gray"))

    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")

    plt.close(fig)
    return fig


def plot_parameter_comparison(
    time_sig: np.ndarray,
    signal: np.ndarray,
    results_20ms: dict,
    results_30ms: dict,
    eval_20ms: dict,
    eval_30ms: dict,
    results_25ms: Optional[dict] = None,
    eval_25ms: Optional[dict] = None,
    wav_name: str = "",
    save_path: Optional[str] = None,
    title: str = "Khảo sát ảnh hưởng của độ dài khung (20 ms vs 25 ms [Chuẩn] vs 30 ms)",
):
    """Plot comprehensive 3-panel comparison between 20ms, 25ms, and 30ms frame lengths:

    1. Waveform.
    2. Overlaid F0 contours (20ms, 25ms, 30ms) with Ground Truth reference.
    3. Bar chart of key metrics (Mean error, Voiced frame count, Classification Accuracy).
    """
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(14, 11), gridspec_kw={"height_ratios": [1, 1.3, 1]})
    fig.suptitle(f"{title}\nFile: {wav_name}", fontsize=14, fontweight="bold")

    # 1. Waveform
    ax1.plot(time_sig, signal, color="#444444", linewidth=0.8, label="Dạng sóng tín hiệu")
    ax1.set_title("1. Dạng sóng tín hiệu (Waveform)", fontsize=11, fontweight="bold")
    ax1.set_ylabel("Biên độ")
    ax1.grid(True, linestyle="--", alpha=0.5)
    ax1.legend(loc="upper right")

    # 2. Overlaid F0 contours
    t_20 = results_20ms["frame_times"]
    f0_20 = np.where(results_20ms["f0_contour"] > 0, results_20ms["f0_contour"], np.nan)

    t_30 = results_30ms["frame_times"]
    f0_30 = np.where(results_30ms["f0_contour"] > 0, results_30ms["f0_contour"], np.nan)

    ref_mean = eval_30ms.get("ref_f0_mean", 0.0)

    ax2.plot(t_20, f0_20, "o--", color="#ff7f0e", markersize=3, linewidth=1.1, alpha=0.7,
             label=f"Khung 20 ms (F0mean={eval_20ms['pred_f0_mean']} Hz, Err={eval_20ms['abs_error_mean']} Hz)")

    if results_25ms is not None and eval_25ms is not None:
        t_25 = results_25ms["frame_times"]
        f0_25 = np.where(results_25ms["f0_contour"] > 0, results_25ms["f0_contour"], np.nan)
        ax2.plot(t_25, f0_25, "d-", color="#2ca02c", markersize=4, linewidth=1.8, alpha=0.95,
                 label=f"Khung 25 ms [Chuẩn] (F0mean={eval_25ms['pred_f0_mean']} Hz, Err={eval_25ms['abs_error_mean']} Hz)")

    ax2.plot(t_30, f0_30, "s--", color="#1f77b4", markersize=3, linewidth=1.1, alpha=0.7,
             label=f"Khung 30 ms (F0mean={eval_30ms['pred_f0_mean']} Hz, Err={eval_30ms['abs_error_mean']} Hz)")

    if ref_mean is not None and ref_mean > 0:
        ax2.axhline(ref_mean, color="black", linestyle=":", linewidth=2.0, label=f"Ground Truth F0mean = {ref_mean} Hz")

    ax2.set_title("2. So sánh đường bao tần số F0 (F0 Contours)", fontsize=11, fontweight="bold")
    ax2.set_ylabel("F0 (Hz)")
    ax2.set_ylim(50, 420)
    ax2.grid(True, linestyle="--", alpha=0.5)
    ax2.legend(loc="upper right", frameon=True)

    # 3. Bar chart of comparison metrics; missing measurements are not zero bars.
    labels_bar = ["Sai số F0mean (|ΔF0| Hz)", "Sai số F0std (|Δstd| Hz)", "Số khung Voiced phát hiện", "Độ chính xác V/UV (%)"]
    vals_20 = [
        eval_20ms["abs_error_mean"],
        eval_20ms["abs_error_std"],
        results_20ms["num_voiced"],
        eval_20ms["classification_accuracy"],
    ]
    vals_30 = [
        eval_30ms["abs_error_mean"],
        eval_30ms["abs_error_std"],
        results_30ms["num_voiced"],
        eval_30ms["classification_accuracy"],
    ]

    vals_20 = np.asarray(vals_20, dtype=float)
    vals_30 = np.asarray(vals_30, dtype=float)
    x = np.arange(len(labels_bar))

    if results_25ms is not None and eval_25ms is not None:
        vals_25 = [
            eval_25ms["abs_error_mean"],
            eval_25ms["abs_error_std"],
            results_25ms["num_voiced"],
            eval_25ms["classification_accuracy"],
        ]
        vals_25 = np.asarray(vals_25, dtype=float)
        width = 0.25
        rects1 = ax3.bar(x - width, vals_20, width, label="Khung 20 ms", color="#ff7f0e", alpha=0.85, edgecolor="gray")
        rects_mid = ax3.bar(x, vals_25, width, label="Khung 25 ms (Chuẩn)", color="#2ca02c", alpha=0.9, edgecolor="black")
        rects2 = ax3.bar(x + width, vals_30, width, label="Khung 30 ms", color="#1f77b4", alpha=0.85, edgecolor="gray")
        all_rects = [rects1, rects_mid, rects2]
    else:
        width = 0.35
        rects1 = ax3.bar(x - width / 2, vals_20, width, label="Khung 20 ms", color="#ff7f0e", alpha=0.85, edgecolor="gray")
        rects2 = ax3.bar(x + width / 2, vals_30, width, label="Khung 30 ms", color="#1f77b4", alpha=0.85, edgecolor="gray")
        all_rects = [rects1, rects2]

    ax3.set_title("3. Bảng số liệu đối sánh định lượng", fontsize=11, fontweight="bold")
    ax3.set_xticks(x)
    ax3.set_xticklabels(labels_bar, fontsize=10)
    ax3.set_xlim(-0.6, len(labels_bar) - 0.4)
    ax3.margins(y=0.15)
    ax3.grid(True, axis="y", linestyle="--", alpha=0.5)
    ax3.legend(loc="upper right")

    # Value labels on bars
    for rect_group in all_rects:
        for r in rect_group:
            h = r.get_height()
            label = f"{h:.1f}" if np.isfinite(h) else "N/A"
            ax3.annotate(label, xy=(r.get_x() + r.get_width() / 2, h if np.isfinite(h) else 0), xytext=(0, 3),
                         textcoords="offset points", ha="center", va="bottom", fontsize=8)

    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")

    plt.close(fig)
    return fig


def plot_frame_cepstrum_comparison(
    voiced_frame: np.ndarray,
    voiced_cep: np.ndarray,
    voiced_f0: float,
    voiced_lag: int,
    voiced_peak: float,
    unvoiced_frame: np.ndarray,
    unvoiced_cep: np.ndarray,
    unvoiced_lag: int,
    unvoiced_peak: float,
    sample_rate: int,
    f0_min: float = 70.0,
    f0_max: float = 400.0,
    threshold: Optional[float] = None,
    save_path: Optional[str] = None,
    title: str = "So sánh Thuật Toán Cepstrum: Khung Hữu Thanh vs Vô Thanh",
):
    """Plot a comprehensive 2x2 comparison of Real Cepstrum between Voiced and Unvoiced frames."""
    n_v = len(voiced_frame)
    n_uv = len(unvoiced_frame)

    t_v = np.arange(n_v) / sample_rate * 1000.0
    t_uv = np.arange(n_uv) / sample_rate * 1000.0

    max_display_ms = 20.0
    max_len = int(round(max_display_ms / 1000.0 * sample_rate))
    max_len_v = min(len(voiced_cep), max_len)
    max_len_uv = min(len(unvoiced_cep), max_len)

    q_v_ms = np.arange(max_len_v) / sample_rate * 1000.0
    q_uv_ms = np.arange(max_len_uv) / sample_rate * 1000.0

    cep_v = voiced_cep[:max_len_v]
    cep_uv = unvoiced_cep[:max_len_uv]

    lag_min = int(round(sample_rate / f0_max))
    lag_max = int(round(sample_rate / f0_min))
    lag_min_ms = lag_min / sample_rate * 1000.0
    lag_max_ms = lag_max / sample_rate * 1000.0

    plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    fig.suptitle(title, fontsize=15, fontweight="bold", y=0.98)

    ax1 = axes[0, 0]
    ax1.plot(t_v, voiced_frame, color="#1f77b4", linewidth=1.5, label="Voiced signal")
    ax1.set_title("1. Tín hiệu Khung Hữu Thanh (Voiced Waveform)", fontsize=12, fontweight="bold", color="#1f77b4")
    ax1.set_xlabel("Thời gian (ms)")
    ax1.set_ylabel("Biên độ")
    ax1.grid(True, linestyle="--", alpha=0.6)
    ax1.legend(loc="upper right")

    ax2 = axes[1, 0]
    ax2.plot(q_v_ms, cep_v, color="#1f77b4", linewidth=1.5, label="Real Cepstrum c(m)")
    ax2.axvspan(lag_min_ms, lag_max_ms, color="green", alpha=0.15, label=f"Vùng tìm F0 [{f0_min:.0f}-{f0_max:.0f} Hz]")
    ax2.axvspan(0, 2.0, color="gray", alpha=0.12, label="Vùng Formant thanh đạo (< 2ms)")
    t0_ms = voiced_lag / sample_rate * 1000.0
    ax2.plot(t0_ms, voiced_peak, "ro", markersize=8, label=f"Đỉnh quefrency q0 = {t0_ms:.2f} ms\nF0 = {voiced_f0:.1f} Hz (Peak: {voiced_peak:.3f})")
    ax2.axvline(t0_ms, color="red", linestyle="--", alpha=0.7)
    if threshold is not None:
        ax2.axhline(threshold, color="purple", linestyle=":", linewidth=1.8, label=f"Ngưỡng T = {threshold:.3f}")
    ax2.set_title(f"Cepstrum Khung Hữu Thanh -> F0 = {voiced_f0:.1f} Hz (Đỉnh nhọn quefrency)", fontsize=12, fontweight="bold", color="darkgreen")
    ax2.set_xlabel("Quefrency (ms)")
    ax2.set_ylabel("Biên độ Cepstrum")
    valid_c = cep_v[int(sample_rate * 0.001):]
    if len(valid_c) > 0:
        ax2.set_ylim(min(-0.1, np.min(valid_c) * 1.2), max(voiced_peak * 1.35, 0.4))
    ax2.grid(True, linestyle="--", alpha=0.6)
    ax2.legend(loc="upper right")

    ax3 = axes[0, 1]
    ax3.plot(t_uv, unvoiced_frame, color="#d62728", linewidth=1.2, label="Unvoiced signal")
    ax3.set_title("2. Tín hiệu Khung Vô Thanh (Unvoiced Waveform)", fontsize=12, fontweight="bold", color="#d62728")
    ax3.set_xlabel("Thời gian (ms)")
    ax3.set_ylabel("Biên độ")
    ax3.grid(True, linestyle="--", alpha=0.6)
    ax3.legend(loc="upper right")

    ax4 = axes[1, 1]
    ax4.plot(q_uv_ms, cep_uv, color="#d62728", linewidth=1.5, label="Real Cepstrum c(m)")
    ax4.axvspan(lag_min_ms, lag_max_ms, color="orange", alpha=0.15, label=f"Vùng tìm F0 [{f0_min:.0f}-{f0_max:.0f} Hz]")
    ax4.axvspan(0, 2.0, color="gray", alpha=0.12, label="Vùng Formant thanh đạo (< 2ms)")
    unvoiced_t0_ms = unvoiced_lag / sample_rate * 1000.0
    ax4.plot(unvoiced_t0_ms, unvoiced_peak, "kx", markersize=8, markeredgewidth=2, label=f"Cực đại cục bộ ({unvoiced_peak:.3f} < Ngưỡng)")
    if threshold is not None:
        ax4.axhline(threshold, color="purple", linestyle=":", linewidth=1.8, label=f"Ngưỡng T = {threshold:.3f}")
    ax4.set_title("Cepstrum Khung Vô Thanh -> F0 không xác định (Nhiễu phẳng)", fontsize=12, fontweight="bold", color="darkred")
    ax4.set_xlabel("Quefrency (ms)")
    ax4.set_ylabel("Biên độ Cepstrum")
    valid_uv = cep_uv[int(sample_rate * 0.001):]
    if len(valid_uv) > 0:
        ax4.set_ylim(min(-0.1, np.min(valid_uv) * 1.2), max(unvoiced_peak * 2.0, 0.4))
    ax4.grid(True, linestyle="--", alpha=0.6)
    ax4.legend(loc="upper right")

    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        print(f"Saved figure: {save_path}")
    plt.close()
    return fig
