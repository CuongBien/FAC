# Stage 4 — kết quả đã lưu

Nguồn: run `stage4-71a151c01ece1311`; metric `legacy-v1`; [evaluation](inputs/evaluation.json) SHA `6cb3ec647409e04bb7527730c903a89703f6745878dbc0af4abcaa67684661ae`; [config](inputs/frozen_config.json) SHA `83dfda76c5a2ce34846a8c4eff9132296e2c09846e4d8e2cf44bbac5be884dc5`; [model](inputs/frozen_models.json) SHA `132f49c80d3f0973424a237a4a7cf83bab82f14f1dd03663f3af720b6f09084f`.

Kết quả từ cấu hình đóng băng và dữ liệu đánh giá đã lưu; không chạy lại thí nghiệm khi dựng báo cáo.

## Phạm vi và giao thức

- Khảo sát 222 cấu hình, 888 lượt cấu hình/file trên 4 WAV train.
- Pha 1: đủ 16 tổ hợp BP/Clip/Energy/Viterbi ở cấu hình lịch sử. Pha 2: hai tổ hợp tốt nhất cộng Champion lịch sử, khung 20/25/30 ms và lưới ngưỡng định trước.
- Hop cố định 10 ms, F0 70–400 Hz, clipping 40%, hệ số Energy/Viterbi giữ nguyên. Không khẳng định đã tìm tối ưu toàn bộ không gian tham số.
- Tiêu chí: trung bình Final Score các file train; hòa điểm ưu tiên sai số file tệ nhất, số plugin, khoảng cách tới khung 25 ms, tên plugin và ngưỡng.
- Dùng tham chiếu thống kê toàn file để hiệu chỉnh; không gọi đây là huấn luyện Gaussian từ nhãn V/UV. Accuracy/F1 từng khung vẫn không có.
- `frozen_config.json` và `frozen_models.json` có checksum, được ghi trước bước đọc/evaluate test. Các tham số không được chọn lại theo điểm test.
- Test từng được xem trong các lần rà soát trước; đây là lựa chọn theo train với cấu hình cố định khi đánh giá, không phải một test set hoàn toàn chưa từng được quan sát.

## Preset đã chốt

| Thuật toán | Plugin | Frame/hop (ms) | Ngưỡng | Train trước → sau | Test trước → sau |
|---|---|---:|---:|---:|---:|
| ACF | BP + Energy + Viterbi | 30/10 | 0.45 | 3.880 → 2.215 | 4.223 → 2.385 |
| AMDF | Energy + Viterbi | 30/10 | 0.5 | 3.757 → 2.078 | 4.125 → 2.755 |
| CEPSTRUM | BP + Clip + Energy + Viterbi | 30/10 | 0.1 | 15.160 → 11.390 | 21.203 → 22.942 |

Bảng giữ đúng điểm trước/sau đã lưu. Không đổi lựa chọn trên train sau khi xem test; số liệu của một tập nhỏ chưa chứng minh khả năng tổng quát.

![So sánh train/test](figures/pipelines_train_test.png)

![Khảo sát trên train](figures/train_threshold_curves.png)

## Đối chứng các giao thức không giám sát

Mọi dòng dưới dùng khung 25/10 ms, cùng silence gate, ứng viên F0 và median theo từng đoạn. `train_all` fit toàn bộ train có silence; `train_active` fit phần active của train. `input_active` fit riêng active từng file đầu vào; không dùng LAB để fit nhưng là thích nghi trên chính dữ liệu đánh giá. HMM giữ A/pi cố định và reset qua silence/file boundary. Ngưỡng động dùng GMM train và median/STE cục bộ, không ước lượng SNR.

| Giao thức | ACF test (%) | AMDF test (%) | Cepstrum test (%) |
|---|---:|---:|---:|
| historical_static | 5.822 | 6.357 | 48.185 |
| median_train_all | 5.170 | 7.425 | 40.370 |
| otsu_train_all | 6.350 | 7.255 | 53.017 |
| valley_train_all | 18.090 | 6.790 | 71.160 |
| kmeans_train_all | 6.453 | 7.152 | 57.000 |
| gmm_train_all | 5.170 | 6.665 | 33.108 |
| dynamic_train_all | 5.925 | 7.635 | 33.770 |
| median_train_active | 14.575 | 17.335 | 34.733 |
| otsu_train_active | 8.832 | 6.955 | 58.255 |
| valley_train_active | 46.245 | 18.640 | 71.160 |
| kmeans_train_active | 9.525 | 6.955 | 58.343 |
| gmm_train_active | 11.560 | 13.673 | 47.920 |
| dynamic_train_active | 11.730 | 12.450 | 44.578 |
| kmeans2d_train_active | 5.958 | 7.558 | 57.987 |
| hmm_train_active | 12.608 | 12.188 | 44.380 |
| kmeans2d_input_active | 7.635 | 8.165 | 31.635 |
| hmm_input_active | 16.240 | 17.825 | 30.843 |

Các dòng này là đối chứng mô tả; không dùng thứ hạng test để chọn lại preset. Mô hình 2D/HMM fit trên train có kết quả riêng với bản thích nghi theo input.

![Đối chứng giao thức](figures/protocols_test.png)

## Artifact và tái lập

- [Cấu hình đã đóng băng](inputs/frozen_config.json), [mô hình đã fit trên train](inputs/frozen_models.json).
- [Toàn bộ trial theo file](inputs/train/all_trials_per_file.csv), [16 tổ hợp mỗi thuật toán](inputs/train/plugin_sweep.json).
- [Đánh giá đầy đủ](inputs/evaluation.json), [pipeline theo file](inputs/evaluation_pipelines_per_file.csv), [giao thức theo file](inputs/evaluation_protocols_per_file.csv).
- `training_source_snapshot.tar.gz` chứa đúng source theo checksum lúc bắt đầu train; `runtime.json` ghi phiên bản thư viện. Base commit, branch, checksum WAV/LAB và mã đang dùng nằm trong provenance.

```powershell
.\.venv\Scripts\python.exe -B scripts/17_validate_and_calibrate.py train --output-dir outputs/stage4_recheck
.\.venv\Scripts\python.exe -B scripts/17_validate_and_calibrate.py evaluate --output-dir outputs/stage4_recheck
```

Lệnh train từ chối ghi đè freeze; evaluate kiểm tra checksum và dữ liệu train, từ chối ghi đè evaluation đã có. Cache chỉ lưu kết quả tính theo khung và cấu hình chính xác; mọi quyết định/hậu xử lý/DP vẫn chạy bình thường và đã được đối chiếu với đường không cache.

## Giới hạn còn lại

- Không có nhãn V/UV theo thời gian hoặc F0 chuẩn từng khung; Final Score chỉ đo thống kê toàn file.
- Kết quả tốt về mean/std/count không chứng minh đúng contour hoặc hết octave errors. Việc tự gán nhãn dữ liệu cũ không thể thay bằng chứng tham chiếu.
- Chưa có tập kiểm thử mới độc lập sau các vòng phát triển; chưa đủ cơ sở khẳng định preset tối ưu trên mọi giọng/môi trường.
- Word, slide và phép đo T0 thủ công là các đầu ra môn học riêng, chưa được tạo trong đợt sửa code này.


## Truy vết Cepstrum lịch sử

Hai replay là bằng chứng riêng đã lưu; không chạy lại khi render.
- Replay `caaf75109d7388bd70b5fb09261b7fe9987a095f`: {'acf': 3247, 'cepstrum': 0}
- Chỉ sửa nhánh `427c0a4`: {'acf': 0, 'cepstrum': 3247}
- [Replay gốc](inputs/cepstrum_trace.json), [replay sửa nhánh](inputs/legacy_with_cepstrum_branch/cepstrum_trace.json).

